# unet_weight
A small repository for demoing image processing on gcp. It will create the weighted image used by u-net.

# Installation
```bash
sudo pip install git+https://github.com/Dammi87/unet_weight
```
# Run example
In terminal:
```bash
python -m unet.label.convert -i IMAGE_PATH -o FOLDER_PATH
```
